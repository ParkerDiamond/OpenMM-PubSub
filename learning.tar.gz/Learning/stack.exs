defmodule Stack do

    def init(_opts) do
        Agent.start_link(fn -> [] end)
    end

    def push(stack, item) do
        Agent.update(stack, fn list -> [ item | list ] end)
    end

    def pop(stack) do
        top = Agent.get(stack, fn list -> hd(list) end)
        Agent.update(stack, fn list-> tl(list) end)
        top
    end

end

{:ok, stack} = Stack.init([])
Stack.push(stack, 4)
Stack.push(stack, 3)
Stack.push(stack, 2)
Stack.push(stack, 1)
IO.puts(Stack.pop(stack))
IO.puts(Stack.pop(stack))
IO.puts(Stack.pop(stack))
IO.puts(Stack.pop(stack))
